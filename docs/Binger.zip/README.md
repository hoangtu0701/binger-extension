# binger-extension
Chrome extension for synced movie watching and chat on Phimbro.
